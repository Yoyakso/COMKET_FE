import React, { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWorkspaceStore } from '@/stores/workspaceStore';
import { useUserStore } from '@/stores/userStore';
import { useOutsideClick } from '@/hooks/useOutsideClick';
import { PortalDropdown } from '@/utils/PortalDropdown';
import * as S from './WorkspaceSelectorDropdown.Style';
import { getWorkspaceMembers } from '@/api/Member';
import { exitWorkspace } from '@/api/Workspace';
import { WorkspaceExit } from './WorkspaceExit';
import { ChevronRight } from 'lucide-react';

interface Props {
  triggerRef: React.RefObject<HTMLElement>;
  close: () => void;
}

export const WorkspaceSelectorDropdown = ({ triggerRef, close }: Props) => {
  const navigate = useNavigate();

  /* ────────── 스토어 ────────── */
  const {
    workspaceId,
    workspaceSlug,
    setWorkspaceStore,
    myWorkspaces: workspaces,
  } = useWorkspaceStore();

  const email = useUserStore(s => s.email);

  /* ────────── 상태 ────────── */
  const [showExitModal, setShowExitModal] = useState(false);
  const [showSub, setShowSub] = useState(false);
  const [isOwner, setIsOwner] = useState(false);

  /* ────────── ref ────────── */
  const dropdownRef = useRef<HTMLDivElement>(null);

  /* ────────── 권한 체크 ────────── */
  useEffect(() => {
    const fetchMyRole = async () => {
      if (!email || !workspaceId) return;
      try {
        const members = await getWorkspaceMembers(workspaceId);
        const me = members.find(m => m.email === email);
        setIsOwner(me?.positionType === 'OWNER');
      } catch (err) {
        console.error('권한 확인 실패', err);
      }
    };
    fetchMyRole();
  }, [email, workspaceId]);

  /* ────────── 드롭다운 외부 클릭 ────────── */
  useOutsideClick([triggerRef, dropdownRef], close);

  /* ────────── 워크스페이스 선택 ────────── */
  const handleSelect = (ws: (typeof workspaces)[number]) => {
    setWorkspaceStore({
      workspaceId: ws.id,
      workspaceName: ws.name,
      workspaceSlug: ws.slug,
      profileFileUrl: ws.profileFileUrl ?? '',
    });
    navigate(`${ws.slug}/settings`);
    close();
  };

  /* ────────── 워크스페이스 나가기 ────────── */
  const handleExit = async () => {
    try {
      const emailInStorage = localStorage.getItem('email');
      const { workspaceId: id, clearWorkspace } = useWorkspaceStore.getState();

      if (!emailInStorage || !id) throw new Error('이메일 또는 워크스페이스 ID가 없습니다.');

      await exitWorkspace({ workspaceId: id.toString(), email: emailInStorage });

      clearWorkspace();
      localStorage.removeItem('workspaceId');
      localStorage.removeItem('workspaceSlug');
      localStorage.removeItem('workspaceName');

      navigate('/workspace', { replace: true });
      window.location.reload();
    } catch (err) {
      console.error('워크스페이스 나가기 실패:', err);
      alert('워크스페이스 나가기에 실패했습니다.');
    }
  };

  /* ────────── 렌더링 ────────── */
  return (
    <PortalDropdown triggerRef={triggerRef}>
      <div ref={dropdownRef}>
        <S.Dropdown>
          <S.Option onClick={() => navigate(`/${workspaceSlug}/settings`)}>
            워크스페이스 정보
          </S.Option>
          <S.Option onClick={() => navigate('/')}>플랜 관리</S.Option>
          <S.Option onClick={() => navigate(`/${workspaceSlug}/member`)}>멤버 관리</S.Option>
          <S.Option onClick={() => navigate(`/${workspaceSlug}/project`)}>프로젝트 관리</S.Option>

          {/* ────────── 서브메뉴 ────────── */}
          <S.SubWrapper
            onMouseEnter={() => setShowSub(true)}
            onMouseLeave={() => setShowSub(false)}
          >
            <S.Option>
              워크스페이스 변경 <ChevronRight />
            </S.Option>

            {showSub && (
              <S.SubDropdown>
                {workspaces.map(ws => (
                  <S.SubOption
                    key={ws.id}
                    onClick={() => handleSelect(ws)}
                    $active={ws.slug === workspaceSlug}
                  >
                    {ws.profileFileUrl ? <S.Img src={ws.profileFileUrl} /> : <S.PlaceholderIcon />}
                    {ws.name}
                  </S.SubOption>
                ))}

                <S.Divider />

                <S.SubOption onClick={() => navigate('/workspace/create')}>
                  신규 워크스페이스 생성
                </S.SubOption>
              </S.SubDropdown>
            )}
          </S.SubWrapper>

          <S.Option onClick={() => setShowExitModal(true)}>워크스페이스 나가기</S.Option>
        </S.Dropdown>
      </div>

      {showExitModal && (
        <WorkspaceExit
          isOwner={isOwner}
          onClose={() => setShowExitModal(false)}
          onExit={handleExit}
        />
      )}
    </PortalDropdown>
  );
};
