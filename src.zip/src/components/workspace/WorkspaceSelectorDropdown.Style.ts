import styled from 'styled-components';
import { color } from '@/styles/color';

export interface SubOptionProps {
  $active?: boolean;
}

export const Dropdown = styled.div`
  min-width: 220px;
  background: #fff;
  border: 1px solid ${color.basic200};
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
  border-radius: 8px;
  padding: 6px 0;
  position: absolute;
  z-index: 9999;
`;

export const Option = styled.div`
  width: 100%;
  padding: 8px 14px;
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  border: 0;
  cursor: pointer;
  position: relative;

  &:hover {
    background: ${color.basic100};
  }
`;

export const SubOption = styled(Option)<SubOptionProps>`
  white-space: nowrap;
  z-index: 9999;

  ${({ $active }) =>
    $active &&
    `
      font-weight: 600;
      background: ${color.basic100};
    `}
`;

export const Img = styled.img`
  width: 20px;
  height: 20px;
  object-fit: cover;
  border-radius: 4px;
`;

export const PlaceholderIcon = styled.div`
  width: 20px;
  height: 20px;
  border-radius: 4px;
  background: ${color.basic200};
`;

export const Divider = styled.hr`
  margin: 4px 0;
  height: 1px;
  background: ${color.basic200};
  border: 0;
`;

export const Create = styled.button`
  width: 100%;
  padding: 8px 14px;
  border: 0;
  background: transparent;
  font-size: 14px;
  color: ${color.primary};
  cursor: pointer;

  &:hover {
    background: ${color.basic100};
  }
`;

export const SubWrapper = styled.div`
  position: relative; /* 서브메뉴 기준점 */
`;

export const SubDropdown = styled.div`
  position: absolute;
  top: 0;
  left: 100%;
  margin-left: 4px;
  min-width: 180px;
  background: white;
  border: 1px solid ${color.basic200};
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  border-radius: 8px;
  z-index: 9999;
`;
