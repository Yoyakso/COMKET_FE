import { SettingNavBar } from './SettingNavBar';
import { ProjectNavBar } from './ProjectNavBar';

export interface NavigationBarProps {
  variant?: 'settings' | 'project';
}

export const LocalNavBar = ({ variant = 'settings' }: NavigationBarProps) => {
  if (variant === 'project') return <ProjectNavBar />;
  return <SettingNavBar />;
};
