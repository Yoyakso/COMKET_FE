import * as S from './LocalNavBar.Style';
import { useNavigate } from 'react-router-dom';
import { useWorkspaceStore } from '@/stores/workspaceStore';
import { NavProfile } from './NavProfile';
import { FolderIcon, ChevronRight, ChevronDown } from 'lucide-react';
import { useEffect, useState } from 'react';
import { getAllProjects, getMyProjects } from '@/api/Project';

interface ProjectData {
  id: number;
  name: string;
}

interface ProjectNavBarProps {
  onNavigateProject?: () => void;
}

export const ProjectNavBar = ({ onNavigateProject }: ProjectNavBarProps) => {
  const navigate = useNavigate();
  const slug = useWorkspaceStore(s => s.workspaceSlug);
  const name = useWorkspaceStore(s => s.workspaceName);
  console.log('[DEBUG] ProjectNavBar workspaceName:', name);
  const profileFileUrl = useWorkspaceStore(s => s.profileFileUrl);

  const [isAllProjectsOpen, setIsAllProjectsOpen] = useState(true);
  const [isMyProjectsOpen, setIsMyProjectsOpen] = useState(false);
  const [allProjects, setAllProjects] = useState<ProjectData[]>([]);
  const [myProjects, setMyProjects] = useState<ProjectData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        setLoading(true);
        const [all, mine] = await Promise.all([getAllProjects(name), getMyProjects(name)]);

        setAllProjects(all);
        setMyProjects(mine);
      } catch (error) {
        console.error('프로젝트 목록 불러오기 실패:', error);
      } finally {
        setLoading(false);
      }
    };

    if (name) fetchProjects();
  }, [name]);

  const renderProjectList = (projects: ProjectData[]) => {
    return projects.map(project => (
      <S.ProjectItem
        key={project.id}
        onClick={() => {
          onNavigateProject?.();
          navigate(`/${slug}/project/${project.id}`);
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <FolderIcon size={16} />
          <span>{project.name}</span>
        </div>
      </S.ProjectItem>
    ));
  };
  if (loading) {
    return <S.NavContainer>로딩 중...</S.NavContainer>;
  }

  return (
    <S.NavContainer>
      <S.NavContent>
        <S.SectionContainer>
          <S.SectionTitle>{name}</S.SectionTitle>
          <S.ItemsContainer>
            <S.NavItem onClick={() => navigate(`/${slug}/mytickets`)}>내 티켓 모아보기</S.NavItem>
          </S.ItemsContainer>
        </S.SectionContainer>

        <S.SectionContainer>
          <S.ProjectSectionHeader>
            <S.ProjectSectionTitle onClick={() => setIsAllProjectsOpen(prev => !prev)}>
              {isAllProjectsOpen ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
              전체 프로젝트
            </S.ProjectSectionTitle>
          </S.ProjectSectionHeader>
          {isAllProjectsOpen && (
            <S.ItemsContainer>{renderProjectList(allProjects)}</S.ItemsContainer>
          )}
        </S.SectionContainer>

        <S.SectionContainer>
          <S.ProjectSectionHeader>
            <S.ProjectSectionTitle onClick={() => setIsMyProjectsOpen(prev => !prev)}>
              {isMyProjectsOpen ? <ChevronDown size={16} /> : <ChevronRight size={16} />}내 프로젝트
            </S.ProjectSectionTitle>
          </S.ProjectSectionHeader>
          {isMyProjectsOpen && <S.ItemsContainer>{renderProjectList(myProjects)}</S.ItemsContainer>}
        </S.SectionContainer>
      </S.NavContent>

      <S.Divider />
      <S.NavProfileContainer>
        <NavProfile name={name} defaultImage={profileFileUrl} />
      </S.NavProfileContainer>
    </S.NavContainer>
  );
};
