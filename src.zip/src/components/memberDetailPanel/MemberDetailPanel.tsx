import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, Copy, Check } from 'lucide-react';
import * as S from './MemberDetailPanel.Style';
import { useOutsideClick } from '@/hooks/useOutsideClick';
import { getWorkspaceMembers } from '@/api/Member';
import { AvatarWithName } from '@/components/ticket/AvatarWithName';
import { useWorkspaceStore } from '@/stores/workspaceStore';
import { UserStatusBadge } from '@/components/common/badge/UserStatusBadge';

interface MemberDetailPanelProps {
  memberId: number;
  onClose: () => void;
}

export const MemberDetailPanel = ({ memberId, onClose }: MemberDetailPanelProps) => {
  const modalRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);
  const [user, setUser] = useState<any | null>(null);
  const workspaceId = useWorkspaceStore(s => s.workspaceId);

  useOutsideClick(modalRef, onClose);

  useEffect(() => {
    const fetchMember = async () => {
      const members = await getWorkspaceMembers(workspaceId);
      console.log('🔥 모든 멤버:', members);
      const found = members.find((m: any) => m.workspaceMemberId === memberId);
      console.log('🔥 찾은 멤버:', found);
      setUser(found);
    };
    if (workspaceId && memberId) fetchMember();
  }, [workspaceId, memberId]);

  if (!user) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(user.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return createPortal(
    <div
      style={{
        position: 'fixed',
        top: 100,
        left: 100,
        background: '#fff',
        zIndex: 99999,
        border: '100px solid red',
      }}
    >
      <div>🔥 패널 테스트: {memberId}</div>
      <button onClick={onClose}>닫기</button>
    </div>,
    document.body,
    // <S.ModalOverlay>
    //   <S.ModalContainer ref={modalRef}>
    //     <S.Header>
    //       <S.ProfileSection>
    //         <S.AvatarWrapper>
    //           <AvatarWithName user={user} />
    //         </S.AvatarWrapper>
    //         <UserStatusBadge email={user.email} />
    //       </S.ProfileSection>
    //       <S.CopyButton onClick={onClose} aria-label="닫기">
    //         <X size={20} />
    //       </S.CopyButton>
    //     </S.Header>

    //     <S.DetailsContainer>
    //       <S.DetailItem>
    //         <S.DetailLabel>이메일</S.DetailLabel>
    //         <S.EmailContainer>
    //           <S.DetailValue>{user.email}</S.DetailValue>
    //           <S.CopyButton onClick={handleCopy}>
    //             {copied ? <Check size={16} /> : <Copy size={16} />}
    //           </S.CopyButton>
    //         </S.EmailContainer>
    //       </S.DetailItem>

    //       <S.DetailItem>
    //         <S.DetailLabel>소속</S.DetailLabel>
    //         <S.DetailValue>{user.department}</S.DetailValue>
    //       </S.DetailItem>
    //       <S.DetailItem>
    //         <S.DetailLabel>직책</S.DetailLabel>
    //         <S.DetailValue>{user.position}</S.DetailValue>
    //       </S.DetailItem>
    //       <S.DetailItem>
    //         <S.DetailLabel>직무</S.DetailLabel>
    //         <S.DetailValue>{user.jobTitle}</S.DetailValue>
    //       </S.DetailItem>
    //       <S.DetailItem>
    //         <S.DetailLabel>역할</S.DetailLabel>
    //         <S.DetailValue>{user.role}</S.DetailValue>
    //       </S.DetailItem>

    //       <S.ProjectsContainer>
    //         {user.projects?.map((p: string) => <S.DetailValue key={p}>{p}</S.DetailValue>)}
    //       </S.ProjectsContainer>
    //     </S.DetailsContainer>
    //   </S.ModalContainer>
    // </S.ModalOverlay>,
    // document.body,
  );
};
