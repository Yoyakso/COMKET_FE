import styled from 'styled-components';
import { color } from '@/styles/color';

export const ModalOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
`;

export const ModalContainer = styled.div`
  max-width: 448px;
  width: 100%;
  border-radius: 8px;
  background-color: ${color.white};
  box-shadow:
    0px 10px 15px -3px rgba(0, 0, 0, 0.1),
    0px 4px 6px -2px rgba(0, 0, 0, 0.05);
  overflow: hidden;
  max-height: calc(100vh - 32px);
  display: flex;
  flex-direction: column;
`;

export const Header = styled.div`
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  padding: 16px;
  border-bottom: 1px solid ${color.basic200};
`;

export const ProfileSection = styled.div`
  display: flex;
  flex-direction: column;
`;

export const AvatarWrapper = styled.div`
  transform: scale(2);
  transform-origin: left center;
  margin-bottom: 16px;
  margin-left: 8px;
`;

export const DetailsContainer = styled.div`
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 16px;
  overflow-y: auto;
`;

export const DetailItem = styled.div``;

export const DetailLabel = styled.p`
  font-size: 14px;
  color: ${color.textSecondary};
  margin-bottom: 4px;
  margin-top: 0;
`;

export const DetailValue = styled.p`
  font-size: 14px;
  color: ${color.textPrimary};
  margin: 0;
`;

export const EmailContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

export const CopyButton = styled.button`
  color: ${color.basic500};
  background: none;
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 4px;
  border-radius: 4px;

  &:hover {
    color: ${color.basic700};
    background-color: ${color.basic100};
  }
`;

export const ProjectsContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 4px;
`;
